// C++ program to print all paths from a source to destination.
#include<iostream>
#include <list>
using namespace std;

int auxw = 0;

struct Min{
	int weight;
	int *path;
	int index;
}; 

struct Node{
	int des;
	int weight;
};


// A directed graph using adjacency list representation
class Graph
{
	int V; // No. of vertices in graph
	list<Node> *adj; // Pointer to an array containing adjacency lists
	Min min;

	// A recursive function used by printAllPaths()
	void printAllPathsUtil(int , int , bool [], int [], int &);

public:
	Graph(int V); // Constructor
	void addEdge(int u, int v, int w);
	void printShortestPath(int s, int d);
};

Graph::Graph(int V)
{
	this->V = V;
	adj = new list<Node>[V];
	min.weight = 1000000;
	min.path = new int[V];
	min.index = 0;
}

void Graph::addEdge(int u, int v, int w)
{
	Node node;
	node.des=v;
	node.weight=w;
	adj[u].push_back(node); // Add destination and weight of edge to u�s list.
}

// Prints all paths from 's' to 'd'
void Graph::printShortestPath(int s, int d)
{
	// Mark all the vertices as not visited
	bool *visited = new bool[V];
	
	// Initialize all vertices as not visited
	for (int i = 0; i < V; i++)
		visited[i] = false;
	
	// Create an array to store paths
	int *path = new int[V];
	int path_index = 0; // Initialize path[] as empty

	// Call the recursive helper function to print all paths 
	printAllPathsUtil(s, d, visited, path, path_index); //returns shortest path;
	
	/*
	print shortest path
	
	*/
	cout << "Shortest path value: " << min.weight << "\n Path: ";
	for(int i = 0; i < min.index; i++){
		cout << min.path[i] << " ";
	}
	cout << endl;
}

// A recursive function to print all paths from 'u' to 'd'.
// visited[] keeps track of vertices in current path.
// path[] stores actual vertices and path_index is current
// index in path[]
void Graph::printAllPathsUtil(int u, int d, bool visited[], int path[], int &path_index)
{
	// Mark the current node and store it in path[]
	visited[u] = true;
	path[path_index] = u;
	path_index++;
	
	list<Node> conexoes = adj[u];
	Node aux;
	// If current vertex is same as destination, then print
	// current path[]
	if (u == d)
	{
		/*for (int i = 0; i<path_index; i++)
			cout << path[i] << " ";
		cout << endl;*/
		
		if(auxw < min.weight)
		{
			min.weight = auxw;
			for (int i = 0; i<path_index; i++){
				min.path[i] = path[i];
			}
			min.index = path_index;			
		}
	}
	else // If current vertex is not d  estination
	{
		
		// Recur for all the vertices adjac
		for(int i = 0; i < adj[u].size(); i++){	
			aux = conexoes.front();		
			conexoes.pop_front();
			if(aux.weight == 0){
				break;
			}  
			if (!visited[aux.des])
			{
				auxw = auxw + aux.weight;
				printAllPathsUtil(aux.des, d, visited, path, path_index);	
			}
			auxw = auxw - aux.weight;
		}
	}

	// Remove current vertex from path[] and mark it as unvisited
	path_index--;
	visited[u] = false;
}

// Driver program
int main()
{
	// Create a graph given in the above diagram
	Graph g(4);
	g.addEdge(0, 1, 3);
	g.addEdge(0, 3, 7);
	g.addEdge(2, 0, 5);
	g.addEdge(2, 1, 1);
	g.addEdge(1, 3, 2);

	int s = 2, d = 3;
	cout << "Following is the shortest path from " << s
		<< " to " << d << endl;
	g.printShortestPath(s, d);

	return 0;
}

