#include <string>
#include <vector>
#include <iostream>
#include <limits>

using namespace std;

class Matriz
{
public:
    static vector<vector<int> > ReturnMatriz(int size1, int size2)
    {
        vector<vector<int> > newVector(size1);
        for (int vector1 = 0; vector1 < size1; vector1++)
        {
            newVector[vector1] = vector<int>(size2);
        }

        return newVector;
    }
};

class OptimizacaoOrden
{
protected:
	vector<vector<int> > m;
	vector<vector<int> > s;
public:
	void getOrder(vector<int> &dims);

	void printOrder();

	void printOrder(vector<vector<int> > &s, int i, int j, vector<bool> &inAResult);
};


void OptimizacaoOrden::getOrder(vector<int> &dims)
{
	int n = dims.size() - 1;
	m = Matriz::ReturnMatriz(n, n);
	s = Matriz::ReturnMatriz(n, n);

	for (int lenMinusOne = 1; lenMinusOne < n; lenMinusOne++)
	{
		for (int i = 0; i < n - lenMinusOne; i++)
		{
			int j = i + lenMinusOne;
			m[i][j] = numeric_limits<int>::max();
			for (int k = i; k < j; k++)
			{
				int cost = m[i][k] + m[k + 1][j] + dims[i]*dims[k + 1]*dims[j + 1];
				if (cost < m[i][j])
				{
					m[i][j] = cost;
					s[i][j] = k;
				}
			}
		}
	}
	cout << "Tot Multilicacoes: " << m[0][n-1] << endl;
}

void OptimizacaoOrden::printOrder()
{
	vector<bool> inAResult(s.size());
	printOrder(s, 0, s.size() - 1, inAResult);
}

void OptimizacaoOrden::printOrder(vector<vector<int> > &s, int i, int j, vector<bool> &inAResult)
{
	if (i != j)
	{
		printOrder(s, i, s[i][j], inAResult);
		printOrder(s, s[i][j] + 1, j, inAResult);
		wstring istr = inAResult[i] ? L"_resultado " : L" ";
		wstring jstr = inAResult[j] ? L"_resultado " : L" ";
		wcout << L" A_" << i << istr << L"* A_" << j << jstr << endl;
		inAResult[i] = true;
		inAResult[j] = true;
	}
}

int main(){
	OptimizacaoOrden matriz;
	vector<int> dims;
	int n;
	
	cout<< "Digite o comprimento das matrices: (Se fim-> Digite 0)" << endl;
	while(cin >> n){
		if(n<1)break;
		dims.push_back(n);
	}
		
	matriz.getOrder(dims);
	matriz.printOrder();
	/*
	//A:30x1, B:1x40, C:40x10 e D:10x25
	//A_1:10x100, B:100x5 e C:5x50	
	dims.push_back(30);
	dims.push_back(1);
	dims.push_back(40);
	dims.push_back(10);
	dims.push_back(25);
	
	OptimizacaoOrden matriz;
	matriz.getOrder(dims);
	matriz.printOrder();
	
	cout << endl;
	
	dims.clear();
	
	dims.push_back(10);
	dims.push_back(100);
	dims.push_back(5);
	dims.push_back(50);
	
	matriz.getOrder(dims);
	matriz.printOrder();
	*/
	return 0;
}
